import java.util.*;

public class Database {
	
	private Map<Integer, Movie> idxToMovie;
	private Map<Integer, Person> idxToPerson;
	private Map<String, Person> nameToPerson;
	private Map<String, List<String>> partialNameToFullName;
	private int idxForPerson, idxForMovie;
	
	public Database() {
		this.idxToMovie = new HashMap<>();
		this.idxToPerson = new HashMap<>();
		this.nameToPerson = new HashMap<>();
		this.partialNameToFullName = new HashMap<>();
		this.idxForPerson = 0;
		this.idxForMovie = 0;
	}
	
	public void addMovie(String movieName, Set<String> listOfName) {
		Movie movie = new Movie(this.idxForMovie, movieName);
		this.idxToMovie.put(this.idxForMovie, movie);
		this.idxForMovie ++;
		
		for (String name : listOfName) {
			
			name = name.toLowerCase();
			
			// new person to the system
			if (!nameToPerson.containsKey(name)) {
				Person person = new Person(idxForPerson, name);
				this.idxToPerson.put(idxForPerson, person);
				this.nameToPerson.put(name, person);
				updatePartialNameMap(name);
				
				person.addMovie(movie);
				movie.addPerson(person);
				this.idxForPerson ++;
				
			// existing person
			} else {
				Person person = nameToPerson.get(name);		
				person.addMovie(movie);
				movie.addPerson(person);
			}

		}
			
	}
	
	private void updatePartialNameMap(String name) {
		String[] parts = name.split(" ");
		for (String part : parts) {
			if (!this.partialNameToFullName.containsKey(part)) {
				this.partialNameToFullName.put(part, new ArrayList<>());
			}
			
			this.partialNameToFullName.get(part).add(name);
		}
	}
	
	public List<String> findName(String partial) {
		partial = partial.toLowerCase();
		return this.partialNameToFullName.get(partial);
	}
	
	public Person getPerson(String name) {
		name = name.toLowerCase();
		return this.nameToPerson.get(name);
	}
	
	public Movie getMovie(int idx) {
		return idxToMovie.get(idx);
	}
	
	public Person getPerson(int idx) {
		return idxToPerson.get(idx);
	}

}
