import java.util.*;

public class Movie implements Comparable<Movie>{
	
	private int id;
	private String name;
	
	private Set<Person> set;
	
	public Movie(int id, String name) {
		this.id = id;
		this.name = name;
		this.set = new HashSet<>();
	}
	
	public int compareTo(Movie m) {
		return this.id - m.getId();
	}
	
	public void addPerson(Person p) {
		this.set.add(p);
	}
	
	public Set<Person> getPersons() {
		return this.set;
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getName() {
		return name;
	}
	
}
