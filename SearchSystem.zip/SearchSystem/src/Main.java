import java.util.*;
import java.io.*;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Database database = new Database();
		
		try {
			initialize(database);
		} catch (IOException e) {
			System.out.println("Something goes wrong when parsing the film links.");
			return;
		}
		
		while (true) {
			System.out.println("**************************************************************");
			System.out.print("Please enter the names (split by space) or return to exit:");
			String input = in.nextLine();
			if (input.equals("")) {
				System.out.println("GoodBye!");
				break;
			}
			
			String[] inputs = input.split(" ");
			
			// Find the movies for each name. 
			List<Set<Movie>> movieList = findAllMoviesPerName(inputs, database);
			
			// Takes the intersection of the movies from each name.
			List<String> movies = findJointMovies(movieList);
			
			if (movies.size() == 0) {
				System.out.println("Cannot find the movie associated with all names. ");
			} else {
				System.out.println(movies.toString());
			}
		}
	}
	
	public static List<String> findJointMovies(List<Set<Movie>> movieList) {
		List<String> movies = new ArrayList<>();
		if (movieList.size() == 0) {
			return movies;
		}
		
		Set<Movie> result = movieList.get(0);
		for (Set<Movie> oneList :  movieList) {
			result.retainAll(oneList);
		}
		
		for (Movie movie : result) {
			movies.add(movie.getName());
		}
		
		return movies;
	}
	
	public static List<Set<Movie>> findAllMoviesPerName(String[] input, Database database) {
		List<Set<Movie>> movieList = new ArrayList<>();
		for (String name : input) {
			if (name.equals("")) {
				continue;
			}
			
			if (database.findName(name) == null) {
				return new ArrayList<>();
			}
			
			// For each given partial name, find out all full names associated with it.
			// Then, concatenate the movie list from each person. 
			Set<Movie> oneList = new HashSet<>();
			for (String each : database.findName(name)) {
				oneList.addAll(database.getPerson(each).getMovies());
			}
	
			movieList.add(oneList);
		}

		return movieList;
	}
	
	public static void initialize(Database database) throws IOException{

		Extractor e = new Extractor();
		Parser parser = new Parser();
		
		boolean loadSuccess = false;
		while (!loadSuccess) {
			loadSuccess = loadFullCreditPages(e);
		}
		
		List<String> listOfMovieLinks = e.getList();
	
		int count = 0;
		for (String movieLink : listOfMovieLinks) {
			
			// For each movie page link, get the "name" information on the page
			parser.doParsing(movieLink);
			String name = parser.getMovieInfo().split("\\(")[0];
			name = name.substring(0, name.length() - 1);
			System.out.println(name);
			
			// Add the new movie and its credit list to the database.
			database.addMovie(name, parser.getCreditList());
			count ++;
			
			if (count % 100 == 0) {
				System.out.println("*******" + count + "/1000 has been loaded. *******");
			}
		}
	}
	
	public static boolean loadFullCreditPages(Extractor e) {
		Scanner in = new Scanner(System.in);
		System.out.print("Choose: 1. Crawl from the website 2. Load from the existing file (enter 1 / 2): ");
		String input = in.nextLine();
		
		if (input.equals("1")) {
			
			String URL = "https://www.imdb.com/search/title/?groups=top_1000&sort=user_rating&view=simple";
			return e.crawlFromWebsite(URL, "fullCreditPages.txt");
			
		} else if (input.equals("2")) {
			
			return e.loadingFromFile("fullCreditPages.txt");
		}
		
		return false;
	}

}
