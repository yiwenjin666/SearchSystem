class SearchSystem {
	
}