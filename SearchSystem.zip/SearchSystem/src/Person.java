import java.util.*;

public class Person implements Comparable<Person>{
	
	private int id;
	private String name;
	private Set<Movie> movies;
	
	public Person(int id, String name) {	
		this.id = id;
		this.name = name;
		this.movies = new HashSet<>();
	}
	
	public void addMovie(Movie m) {
		this.movies.add(m);
	}
	
	public Set<Movie> getMovies() {
		return this.movies;
	}
	
	public int compareTo(Person p) {
		return this.id - p.getId();
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getName() {
		return name;
	}
	
	public String toString() {
		return name;
	}
}
