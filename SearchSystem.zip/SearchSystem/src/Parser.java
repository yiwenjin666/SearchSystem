import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;

public class Parser {
	
	private String movieInfo = "";
	private Set<String> creditList = new HashSet<>();
	
	public Parser() {}
	
	public void doParsing(String URL) throws IOException {	
		Document doc = Jsoup.connect(URL).get();
		movieInfo = doc.title();
		creditList = new HashSet<>();
		
		Elements links = doc.select("a[href]");
        for (Element link : links) {
        	if (link.attr("abs:href").matches("(.*)/name/(.*)")) {
        		if (!link.text().equals("")) {
        			creditList.add(link.text());
        		}
        	}          
        }
	}
	
	public String getMovieInfo() {
		return movieInfo;
	}
	
	public Set<String> getCreditList() {
		return creditList;
	}
	
	
}
