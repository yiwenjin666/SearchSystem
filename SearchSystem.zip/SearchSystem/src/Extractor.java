import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.util.*;

public class Extractor {
	
	private List<String> filmURL;
	private List<String> fullCreditURL;
	
	public Extractor() {
		this.filmURL = new ArrayList<>();
		this.fullCreditURL = new ArrayList<>();
	}
	
	public List<String> getList() {
		return fullCreditURL;
	}
	
	public boolean loadingFromFile(String filename){
		
		try {
			File myObj = new File(filename);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
		        fullCreditURL.add(data);
		    }
			myReader.close();
	    } catch (FileNotFoundException e) {
	    	System.out.println("Cannot find the file: " + filename);
	    	return false;
	    }
		
		return true;
	}
	
	public boolean crawlFromWebsite(String URL, String filename) {
		try {
			extractFilmURL(URL);
			System.out.println("*******Film URLs are loaded successfully.********");
			extractFullCreditPage();
			writeToFile(filename);
		} catch (IOException e) {
			System.out.println("Error when crawling from the website.");
			return false;
		}	
		
		return true;
	}
	
	private void extractFilmURL(String URL) throws IOException{	
		Document doc = Jsoup.connect(URL).get();
		Elements links = doc.select("a[href]");
		
		boolean visited = false;
		
		for (Element link : links) {
        	if (link.attr("abs:href").matches("(.*)ref_=adv_li_i")) {
        		filmURL.add(link.attr("abs:href"));
        	}
        	
        	if (link.attr("abs:href").matches("(.*)ref_=adv_nxt")) {
        		if (visited) {
        			continue;
        		}
        		
        		if (this.filmURL.size() >= 1000) {
        			continue;
        		}
        		
        		visited = true;
        		extractFilmURL(link.attr("abs:href"));
        	}
        }	
	}
	
	
	private void extractFullCreditPage() throws IOException {	
		
		for (String URL : filmURL) {
			Document doc = Jsoup.connect(URL).get();
			Elements links = doc.select("a[href]");
			
			for (Element link : links) {
				
	        	if (link.attr("abs:href").matches("(.*)fullcredits(.*)")) {
	        		fullCreditURL.add(link.attr("abs:href"));
	        		break;
	        	}
	        }
			
			if (fullCreditURL.size() % 100 == 0) {
				System.out.println(fullCreditURL.size() + "/1000 is extracted.");
			}
			
		}
	}
	
	private void writeToFile(String filename) throws IOException{	
		File myObj = new File(filename);
		myObj.createNewFile();
      
		FileWriter myWriter = new FileWriter(filename);
		for (String URL : this.fullCreditURL) {
			myWriter.write(URL + "\n");
		}
      
		myWriter.close();	
	}
}
